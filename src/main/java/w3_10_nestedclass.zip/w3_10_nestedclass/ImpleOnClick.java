package w3_10_nestedclass;

public class ImpleOnClick implements Button.OnClickListener {
    @Override
    public void onClick() {

    }
}
