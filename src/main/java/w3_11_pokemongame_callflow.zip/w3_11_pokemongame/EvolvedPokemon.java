package w3_11_pokemongame;

import lombok.Getter;

@Getter
public class EvolvedPokemon extends Pokemon
          // EvolvedPokemon is a Pokemon : 참인 명제
{

}
