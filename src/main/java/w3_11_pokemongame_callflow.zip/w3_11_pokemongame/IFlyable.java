package w3_11_pokemongame;

public interface IFlyable extends IOceanCrossable {
    public void fly(String tgCity);
}
