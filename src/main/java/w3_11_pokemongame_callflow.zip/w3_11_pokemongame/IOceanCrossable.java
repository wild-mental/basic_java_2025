package w3_11_pokemongame;

public interface IOceanCrossable {
    public void crossOcean(String tgCity);
}
