package w3_11_pokemongame;

public interface ISurfable extends IOceanCrossable {
    public void surf(String tgCity);
}
