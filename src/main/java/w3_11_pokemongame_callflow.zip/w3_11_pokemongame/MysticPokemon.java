package w3_11_pokemongame;

import lombok.Getter;

@Getter
public class MysticPokemon extends Pokemon {}
