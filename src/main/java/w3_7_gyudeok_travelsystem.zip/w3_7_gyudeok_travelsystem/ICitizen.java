package w3_7_gyudeok_travelsystem;
// 인터페이스는 추가 기능을 만들 수 있기에 보류중
abstract interface ICitizen {
    public void travel (Nation nation);
    public void emigration(Nation nation);
}
