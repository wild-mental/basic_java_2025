package w3_7_gyudeok_travelsystem;

public interface IPerson {
    public void travel (Nation nation);  // 시도는 할 수 있게 만들어 봄
    public void emigration(Nation nation);
}
