package w3_7_taeri_travel_system;

public interface ImmigrationPolicy {
    boolean screenImmigration(Citizen citizen, boolean isAtWar);
}
