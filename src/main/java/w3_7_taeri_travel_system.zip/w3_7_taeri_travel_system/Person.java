//package w3_7_taeri_travel_system;
//
//public class Person extends Citizen {
//    public Person(String name) {
//        super(name, "Stateless", false, false);
//    }
//
//    @Override
//    public String toString() {
//        return "StatelessPerson{name='" + super.toString() + "'}";
//    }
//}