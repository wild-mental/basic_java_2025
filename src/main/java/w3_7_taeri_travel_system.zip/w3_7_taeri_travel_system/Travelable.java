package w3_7_taeri_travel_system;

public interface Travelable {
    void travel(Nation targetNation);
    void emigrate(Nation targetNation);
}
