package w3_7_travelsystem;

public interface IControlTravel {
    public boolean screenImmigration(Citizen screenTgPerson, String incomingPurpose);
}
