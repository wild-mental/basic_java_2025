package w3_7_travelsystem;

public interface ITravelable {
    void travel(Nation tgNation);
    void emigration(Nation tgNation);
}
