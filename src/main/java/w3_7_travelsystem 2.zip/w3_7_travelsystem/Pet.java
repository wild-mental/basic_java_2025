package w3_7_travelsystem;

public class Pet implements ITravelable {

    @Override
    public void travel(Nation tgNation) {

    }

    @Override
    public void emigration(Nation tgNation) {

    }
}
