package w3_7_travelsystem;

public class TravelControlDepartmentA implements IControlTravel{
    @Override
    public boolean screenImmigration() {
        return false;
    }
}
