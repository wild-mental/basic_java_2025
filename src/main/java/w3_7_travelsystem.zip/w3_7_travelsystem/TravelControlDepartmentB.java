package w3_7_travelsystem;

public class TravelControlDepartmentB implements IControlTravel{
    @Override
    public boolean screenImmigration() {
        return false;
    }
}
